package studyHall2;

import java.sql.Connnection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q4 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		ResultSet rSet=stmt.executeQuery("select avg(salary) from salaryTable");
		
		String averageSalary="";
		while(rSet.next()){
			averageSalary=rSet.getString(1);
		}
		
		Statement stmt2=conn.createStatement();
		ResultSet rSet2 = stmt2.executeQuery("select emp_id,salary from salaryTable where salary>"+averageSalary+" order by salary desc limit 10");
		while(rSet2.next()){
			int id=rSet2.getInt(1);
			String Actualsalary=rSet2.getString(2);
			System.out.println(id+" ----  "+Actualsalary);
		}
	}
}