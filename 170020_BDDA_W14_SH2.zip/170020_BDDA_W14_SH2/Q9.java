package w14sh2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q9 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		ResultSet rSet = stmt.executeQuery("select Country,sum(Total_Medals) from olympic group by Country");
		System.out.println("Country ==> Medals");
		
		while(rSet.next()){
			String CountryN=rSet.getString(1);
			String MedalsV=rSet.getString(2);
			System.out.println(CountryN+" ==> "+MedalsV);
		}
	}
}